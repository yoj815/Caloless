package caloless.vo;

public class UserVO {
    String userid, upw, uname, uemail, ugender, ugrade;
    int uage, uheight, uweight;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUpw() {
        return upw;
    }

    public void setUpw(String upw) {
        this.upw = upw;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUemail() {
        return uemail;
    }

    public void setUemail(String uemail) {
        this.uemail = uemail;
    }

    public String getUgender() {
        return ugender;
    }

    public void setUgender(String ugender) {
        this.ugender = ugender;
    }

    public String getUgrade() {
        return ugrade;
    }

    public void setUgrade(String ugrade) {
        this.ugrade = ugrade;
    }

    public int getUage() {
        return uage;
    }

    public void setUage(int uage) {
        this.uage = uage;
    }

    public int getUheight() {
        return uheight;
    }

    public void setUheight(int uheight) {
        this.uheight = uheight;
    }

    public int getUweight() {
        return uweight;
    }

    public void setUweight(int uweight) {
        this.uweight = uweight;
    }
}
